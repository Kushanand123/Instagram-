class Story {
  final String image;
  final String name;
  Story(this.image, this.name);
}