package com.example.instagram

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
